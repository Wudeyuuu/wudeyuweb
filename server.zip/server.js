const express = require("express");
const https = require("https");
const fs = require("fs");

const options = {
    key: fs.readFileSync("priv/www.wudeyu.com.key.pem"),
    cert: fs.readFileSync("cert/www.wudeyu.com.cert.pem")
};

const app = express();

app.get("/", (req, res) => {
    res.send("HOLA MUNDO");
});

https.createServer(options, app).listen(4433, () => {
    console.log("Server listening.");
});